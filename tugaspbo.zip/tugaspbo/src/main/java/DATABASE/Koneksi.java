/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DATABASE;

import java.sql.Connection;
import java.sql.DriverManager;
import javax.swing.JOptionPane;

/**
 *
 * @author COMPUTER
 */
public class Koneksi {
    public static Connection konek(){
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection konekDB = DriverManager.getConnection("jdbc:mysql://localhost/tugaspbo","root",""); //databasenya apa,databasenya dimana, apa namanya
            return konekDB; //jika di try dan success maka akan di konekDB yg artinya dia akan melakukan access ulang konekDb
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);//menampilkan pesan error dalam isi dari e
            return null; //misalnya databasenya tidak ada user&pw salah kita tidak melakukan apa2
        }
    }
    
}
